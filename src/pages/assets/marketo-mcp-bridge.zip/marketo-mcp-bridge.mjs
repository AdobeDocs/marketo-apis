import { createInterface } from "node:readline";

const REMOTE_URL = "https://marketo-mcp.adobe.io/mcp";
const AUTH_HEADERS = {
  "X-Marketo-Client-Id": process.env.MARKETO_MCP_PROD_CLIENT_ID,
  "X-Marketo-Client-Secret": process.env.MARKETO_MCP_PROD_CLIENT_SECRET,
  "X-Marketo-Munchkin-Id": process.env.MARKETO_MCP_PROD_MUNCHKIN_ID,
};

let sessionId = null;

function writeMessage(message) {
  process.stdout.write(JSON.stringify(message) + "\n");
}

function emitSseLine(line) {
  if (!line.startsWith("data:")) return;
  try {
    writeMessage(JSON.parse(line.slice(5).trimStart()));
  } catch {}
}

async function consumeSse(body) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) return;
    buffer += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buffer.indexOf("\n")) !== -1) {
      emitSseLine(buffer.slice(0, idx).replace(/\r$/, ""));
      buffer = buffer.slice(idx + 1);
    }
  }
}

async function forward(message) {
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json, text/event-stream",
    ...AUTH_HEADERS,
  };
  if (sessionId) headers["mcp-session-id"] = sessionId;

  const res = await fetch(REMOTE_URL, {
    method: "POST",
    headers,
    body: JSON.stringify(message),
  });

  const newSessionId = res.headers.get("mcp-session-id");
  if (newSessionId) sessionId = newSessionId;

  if (res.status === 202 || res.status === 204) return;

  const contentType = res.headers.get("content-type") || "";
  if (contentType.includes("text/event-stream")) {
    await consumeSse(res.body);
  } else {
    writeMessage(await res.json());
  }
}

createInterface({ input: process.stdin }).on("line", (line) => {
  if (!line.trim()) return;
  let message;
  try {
    message = JSON.parse(line);
  } catch (err) {
    process.stderr.write(`parse error: ${err.message}\n`);
    return;
  }
  forward(message).catch((err) => {
    process.stderr.write(`forward error: ${err.message}\n`);
  });
});
