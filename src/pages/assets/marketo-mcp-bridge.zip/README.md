# Marketo MCP Bridge

A stdio bridge that proxies Marketo MCP tools from the remote server to Claude Desktop.

## Prerequisites

- Node.js v18+
- npm
- Marketo MCP credentials (Client ID, Client Secret, Munchkin ID)

## Download marketo-mcp-bridge.mjs
Download marketo-mcp-bridge.mjs into a known location so you can point to it in step below.

## Configure Claude Desktop

1. Open Claude Desktop
2. Go to **Settings > Developer > Edit Config**
3. Add the following to `claude_desktop_config.json`:

```json
{
  "preferences": {
    ...
  },
  "mcpServers": {
    "marketo-mcp": {
      "command": "node",
      "args": ["/path/to/marketo-bridge/bridge.mjs"],
      "env": {
        "MARKETO_MCP_PROD_CLIENT_ID": "<your-client-id>",
        "MARKETO_MCP_PROD_CLIENT_SECRET": "<your-client-secret>",
        "MARKETO_MCP_PROD_MUNCHKIN_ID": "<your-munchkin-id>"
      }
    }
  }
}
```

> **Note:** If Claude Desktop picks up the wrong Node version (e.g. v14), use the absolute path to your Node binary instead of `"node"`. You can find it with `which node`.

4. Restart Claude Desktop
